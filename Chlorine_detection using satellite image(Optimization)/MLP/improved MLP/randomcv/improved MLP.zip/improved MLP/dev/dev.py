import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
import joblib

# Load the data
input_file_path = 'Input_X.xlsx'
output_file_path = 'Output_Y.xlsx'

input_data = pd.read_excel(input_file_path)
output_data = pd.read_excel(output_file_path)

# Split data into training and testing sets
X = input_data
y = output_data['CHL_a']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Normalize the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Hyperparameter Tuning with Manual Search
best_model = None
best_score = float('-inf')  # Use R^2 score for optimization
best_params = None

hidden_layer_sizes = [(100,), (150, 75), (200, 100, 50)]
alpha_values = [0.0001, 0.001, 0.01]  # L2 regularization (alpha)
learning_rates = [0.001, 0.01]
max_iters = [200, 500]

for hl in hidden_layer_sizes:
    for alpha in alpha_values:
        for lr in learning_rates:
            for mi in max_iters:
                # Train the MLP
                model = MLPRegressor(hidden_layer_sizes=hl, alpha=alpha, learning_rate_init=lr,
                                     max_iter=mi, random_state=42, early_stopping=True)
                model.fit(X_train_scaled, y_train)

                # Evaluate on validation set
                train_pred = model.predict(X_train_scaled)
                score = r2_score(y_train, train_pred)

                if score > best_score:
                    best_score = score
                    best_model = model
                    best_params = {'hidden_layer_sizes': hl, 'alpha': alpha, 'learning_rate_init': lr, 'max_iter': mi}

# Save the best model and scaler
joblib.dump(best_model, 'MLP_Model_Improved.pkl')
joblib.dump(scaler, 'Scaler_Improved.pkl')

# Predict and save training/testing results
y_train_pred = best_model.predict(X_train_scaled)
y_test_pred = best_model.predict(X_test_scaled)

train_results = pd.DataFrame({'Actual': y_train, 'Predicted': y_train_pred})
train_results.to_excel('Training_Results_Improved.xlsx', index=False)

test_results = pd.DataFrame({'Actual': y_test, 'Predicted': y_test_pred})
test_results.to_excel('Testing_Results_Improved.xlsx', index=False)

# Scatter plots with consistent scaling
min_value = min(min(y_train), min(y_test), min(y_train_pred), min(y_test_pred))
max_value = max(max(y_train), max(y_test), max(y_train_pred), max(y_test_pred))

plt.figure(figsize=(12, 6))

# Training scatter plot
plt.subplot(1, 2, 1)
plt.scatter(y_train, y_train_pred, alpha=0.5, color='blue')
plt.xscale('log')
plt.yscale('log')
plt.xlim(min_value, max_value)
plt.ylim(min_value, max_value)
plt.xlabel('Actual Values (Training)')
plt.ylabel('Predicted Values (Training)')
plt.title('Actual vs Predicted - Training Data')
plt.grid()
plt.plot([min_value, max_value], [min_value, max_value], color='black', linewidth=1.5)  # Add 1:1 line

# Testing scatter plot
plt.subplot(1, 2, 2)
plt.scatter(y_test, y_test_pred, alpha=0.5, color='green')
plt.xscale('log')
plt.yscale('log')
plt.xlim(min_value, max_value)
plt.ylim(min_value, max_value)
plt.xlabel('Actual Values (Testing)')
plt.ylabel('Predicted Values (Testing)')
plt.title('Actual vs Predicted - Testing Data')
plt.grid()
plt.plot([min_value, max_value], [min_value, max_value], color='black', linewidth=1.5)  # Add 1:1 line

plt.tight_layout()
plt.savefig('Scatter_Plot_Training_Testing_Improved.png')
plt.show()

print("Best Hyperparameters:", best_params)
print("Best R^2 Score:", best_score)
